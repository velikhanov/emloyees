<footer class="container-fluid" id="contacts">
    <div class="container">
        <div class="row padding text-center">
            <div class="col-12">
                <h2 class="mycontacts">Contacts</h2>
            </div>
            <div class="col-12 social padding">
                <a href="https://www.instagram.com/velihanov99/" target="_blank"><i class="fab fa-instagram"></i></a>
                <a href="https://vk.com/timur_velikhanov" target="_blank"><i class="fab fa-vk" target="_blank"></i></a>
                <a href="https://www.facebook.com/profile.php?id=100004211808796" target="_blank"><i class="fab fa-facebook"></i></a>
                <a href="mailto:teymur99@gmail.com" target="_blank"><i class="fab fa-google-plus"></i></a>
            </div>
        </div>
    </div>
    <h3 class="copyrights">©Copyright 2014-<?= date('Y') ?>, teymur99@gmail.com</h3>
</footer>

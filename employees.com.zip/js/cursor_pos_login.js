var input;
input=document.querySelector("input[name=email]");
input.focus();
input.selectionStart=input.value.length;

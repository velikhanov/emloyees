var input;
input=document.querySelector("input[name=name]");
input.focus();
input.selectionStart=input.value.length;
